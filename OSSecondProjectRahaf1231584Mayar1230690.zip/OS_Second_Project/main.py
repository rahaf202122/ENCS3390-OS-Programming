# main.py

def total_cpu_io_time(p):
    # Calculate total CPU and IO time for a process
    cpu = 0
    io = 0

    for burst in p.burst_time:
        if "CPU" in burst:
            for ev in burst["CPU"]:
                if ev[0] == "T":
                    # Only T events consume CPU time
                    cpu += ev[1]
        if "IO" in burst:
            io += burst["IO"]

    return cpu, io


from input_parser import readFile
from scheduler_priority import run_preemptive_priority_rr_with_io, print_gantt


def main():
    # Read resources and processes from input file
    resources, processes = readFile("input.txt")

    # Run the scheduler
    gantt, procs, deadlock_events = run_preemptive_priority_rr_with_io(
        processes,
        resources=resources,
        quantum=10,
        detect_deadlock=True
    )
    if len(deadlock_events) == 0:
       print("\nNo deadlock occurred during execution.")
    else:
       print(f"\nDeadlock detected {len(deadlock_events)} time(s).")


    # Print Gantt chart
    print("\n=== GANTT CHART ===")
    print_gantt(gantt)

    # Calculate averages for finished processes only
    total_wt = 0
    total_tat = 0
    finished = 0

    print("\n=== PROCESS TIMES (Waiting Time counted only in READY state) ===")
    for p in procs:
        if getattr(p, "killed", False):
            print(
                f"P{p.PID}: KILLED at time {p.kill_time} "
                f"(Deadlock recovery) | WT so far = {p.waiting_time}"
            )
            continue

        ft = getattr(p, "finish_time", None)
        if ft is None:
            continue

        # Turnaround Time = Finish Time - Arrival Time
        tat = ft - p.ArrivalTime

        # Waiting Time is accumulated while in READY queue
        wt = p.waiting_time

        print(f"P{p.PID}: WT={wt}, TAT={tat}, Finish={ft}")

        total_wt += wt
        total_tat += tat
        finished += 1

    print("\n=== AVERAGES (Finished processes only) ===")
    if finished == 0:
        print("No finished processes. Cannot compute averages.")
    else:
        print(f"Average Waiting Time = {total_wt / finished:.2f}")
        print(f"Average Turnaround Time = {total_tat / finished:.2f}")
        print(f"Averages are computed over {finished} finished processes only.")

if __name__ == "__main__":
    main()
    
