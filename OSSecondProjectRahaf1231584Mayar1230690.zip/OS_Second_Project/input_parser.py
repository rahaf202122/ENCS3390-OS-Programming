import re

# ---------------- Process Class ----------------
# This class represents a single process in the system
class Process:
    def __init__(self, pid, ArrivalTime, priority, burst_time,
                 t=0, CPU_burst=0, IO_burst=0, end=0,
                 waiting_time=0, executed=0, turnAroundTime=0,
                 start=None, duration=None, terminated=False):

        # Basic process info
        self.PID = pid
        self.ArrivalTime = ArrivalTime
        self.priority = priority
        self.burst_time = burst_time

        # Scheduler state variables
        self.state = "NEW"
        self.burst_i = 0          # index of current burst
        self.event_i = 0          # index of event inside CPU burst
        self.remaining_T = 0     # remaining CPU time
        self.io_remaining = 0    # remaining IO time

        # RR and aging support
        self.quantum_left = 0
        self.ready_wait = 0
        self.waiting_time = waiting_time

        # Statistics
        self.finish_time = None
        self.executed = executed
        self.end = end
        self.CPU_burst = CPU_burst
        self.IO_burst = IO_burst
        self.turnAroundTime = turnAroundTime
        self.start = start if start is not None else []
        self.duration = duration if duration is not None else []
        self.t = t
        self.terminated = terminated

    # Used when processes are compared (priority queue / sorting)
    def __lt__(self, other):
        if self.priority == other.priority:
            return self.t < other.t
        return self.priority < other.priority

    def __repr__(self):
        return f"P{self.PID}(AT={self.ArrivalTime}, pr={self.priority}, bursts={self.burst_time})"


# ---------------- Parsing Functions ----------------

# Parse resource line like: [1,5], [2,3]
def parse_resources(line: str) -> dict:
    resources = {}
    matches = re.findall(r'\[(\d+)\s*,\s*(\d+)\]', line)
    for rid, inst in matches:
        resources[int(rid)] = int(inst)
    return resources


# Parse CPU events inside CPU{ }
# Example: R[1,2], 50, F[1,1]
def parse_cpu_events(cpu_inside: str):
    events = []
    tokens = re.findall(
        r'R\[\s*\d+\s*,\s*\d+\s*\]|F\[\s*\d+\s*,\s*\d+\s*\]|\d+',
        cpu_inside
    )

    for tok in tokens:
        tok = tok.replace(" ", "")
        if tok.startswith("R["):
            rid, k = map(int, re.findall(r'\d+', tok))
            events.append(("R", rid, k))   # Resource request
        elif tok.startswith("F["):
            rid, k = map(int, re.findall(r'\d+', tok))
            events.append(("F", rid, k))   # Resource release
        else:
            events.append(("T", int(tok))) # CPU time
    return events


# Parse one process line from the input file
def parse_process_line(line: str) -> Process:
    m = re.match(r'^\s*(\d+)\s+(\d+)\s+(\d+)\s+(.*)$', line)
    if not m:
        raise ValueError(f"Bad process line: {line}")

    pid = int(m.group(1))
    arrival = int(m.group(2))
    priority = int(m.group(3))
    rest = m.group(4)

    bursts = []
    pattern = re.compile(r'(CPU|IO)\s*\{?([^}]+)\}?', re.IGNORECASE)
    matches = pattern.findall(rest)

    for burst_type, content in matches:
        if burst_type.upper() == "CPU":
            bursts.append({"CPU": parse_cpu_events(content)})
        elif burst_type.upper() == "IO":
            bursts.append({"IO": int(content.strip())})

    return Process(pid, arrival, priority, bursts)


# Read input file and return resources and processes
def readFile(filename: str):
    with open(filename, "r") as file:
        lines = [ln.strip() for ln in file.readlines() if ln.strip()]

    if not lines:
        raise ValueError("Empty input file")

    # First line contains system resources
    resources = parse_resources(lines[0])
    if not resources:
        raise ValueError("First line must define resources")

    # Remaining lines contain processes
    processes = []
    for line in lines[1:]:
        processes.append(parse_process_line(line))

    return resources, processes
