# deadlock.py

def detect_deadlock_snapshot(resource_ids, available, allocation_by_pid, request_by_pid, trace=False):
    """
    Detect deadlocked processes using the snapshot deadlock detection algorithm
    (as explained in OS lectures).
    """

    # Convert a resource dictionary {resource_id: count}
    # into a vector (list) aligned with resource_ids order
    def dict_to_vec(d):
        return [int(d.get(rid, 0)) for rid in resource_ids]

    # Check if vector a <= vector b (element-wise)
    def vec_leq(a, b):
        return all(a[i] <= b[i] for i in range(len(a)))

    # Add two vectors element by element
    def vec_add(a, b):
        return [a[i] + b[i] for i in range(len(a))]

    # Collect all process IDs from allocation and request tables
    pids = sorted(set(allocation_by_pid.keys()) | set(request_by_pid.keys()))

    # Step 1: Work = Available resources
    work = dict_to_vec(available)

    # Step 2: Initialize Finish array
    # Finish[pid] = True if process has no allocated resources
    finish = {}
    for pid in pids:
        alloc_vec = dict_to_vec(allocation_by_pid.get(pid, {}))
        finish[pid] = (sum(alloc_vec) == 0)

    # Step 3: Try to find a process that can finish
    progress = True
    while progress:
        progress = False
        for pid in pids:
            if finish[pid]:
                continue  # skip already finished processes

            req_vec = dict_to_vec(request_by_pid.get(pid, {}))
            # If request can be satisfied with current work
            if vec_leq(req_vec, work):
                alloc_vec = dict_to_vec(allocation_by_pid.get(pid, {}))
                work = vec_add(work, alloc_vec)  # release its resources
                finish[pid] = True
                progress = True

    # Any process that is not finished is deadlocked
    deadlocked = [pid for pid in pids if not finish[pid]]

    # Optional debug output
    if trace:
        print("\n--- DEADLOCK SNAPSHOT ---")
        print("Available:", available)
        print("Work:", work)
        print("Finish:", finish)
        print("Deadlocked:", deadlocked)

    return deadlocked
