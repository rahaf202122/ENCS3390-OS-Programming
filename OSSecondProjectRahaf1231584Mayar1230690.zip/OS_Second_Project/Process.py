import re
from Process import Process

# Parse the first line to extract system resources
# Format example: [1,3] [2,2]
def parse_resources(line: str) -> dict:
    resources = {}

    # Find all resource pairs [resource_id, instances]
    matches = re.findall(r'\[(\d+)\s*,\s*(\d+)\]', line)
    for rid, inst in matches:
        resources[int(rid)] = int(inst)

    return resources


# Return resource IDs sorted (used for consistent ordering)
def get_resource_ids(resources: dict):
    return sorted(resources.keys())


# Parse CPU events inside CPU { ... }
# R[x,y] -> request y instances of resource x
# F[x,y] -> free y instances of resource x
# number  -> CPU execution time
def parse_cpu_events(cpu_inside: str):
    events = []

    # Extract requests, frees, and time values
    tokens = re.findall(
        r'R\[\s*\d+\s*,\s*\d+\s*\]|F\[\s*\d+\s*,\s*\d+\s*\]|\d+',
        cpu_inside
    )

    for tok in tokens:
        tok = tok.replace(" ", "")

        if tok.startswith("R["):
            rid, k = map(int, re.findall(r'\d+', tok))
            events.append(("R", rid, k))  # Resource request

        elif tok.startswith("F["):
            rid, k = map(int, re.findall(r'\d+', tok))
            events.append(("F", rid, k))  # Resource release

        else:
            events.append(("T", int(tok)))  # CPU time

    return events


# Parse one process line and create a Process object
def parse_process_line(line: str) -> Process:
    # Format: PID Arrival Priority CPU{...} IO{...}
    m = re.match(r'^\s*(\d+)\s+(\d+)\s+(\d+)\s+(.*)$', line)
    if not m:
        raise ValueError(f"Bad process line: {line}")

    pid = int(m.group(1))
    arrival = int(m.group(2))
    priority = int(m.group(3))
    rest = m.group(4).strip()

    # Find CPU and IO bursts
    pattern = re.compile(r'(CPU|IO)\s*\{([^}]*)\}', re.IGNORECASE)
    matches = pattern.findall(rest)

    bursts = []
    for type_, content in matches:
        if type_.upper() == "CPU":
            bursts.append({"CPU": parse_cpu_events(content)})
        elif type_.upper() == "IO":
            bursts.append({"IO": int(content.strip())})

    return Process(pid, arrival, priority, bursts)


# Read input file and return resources and process list
def readFile(filename: str):
    with open(filename, "r") as f:
        # Remove empty lines and extra spaces
        lines = [ln.strip() for ln in f.readlines() if ln.strip()]

    if not lines:
        raise ValueError("Empty input file")

    # First line contains resources
    resources = parse_resources(lines[0])

    # Remaining lines contain process definitions
    processes = [parse_process_line(line) for line in lines[1:]]

    return resources, processes
