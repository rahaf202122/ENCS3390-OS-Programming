# scheduler_priority.py
# Preemptive Priority + RR + Aging + IO + Resources
# MODIFIED: detect/kill ONLY when system is fully stuck (true deadlock time)

from collections import deque
from deadlock import detect_deadlock_snapshot

MIN_P = 0
MAX_P = 20


def add_to_ready(ready, p, time, front=False):
    p.state = "READY"
    p.ready_enter_time = time
    if front:
        ready[p.priority].appendleft(p)
    else:
        ready[p.priority].append(p)


def pick_best_ready(ready):
    for pr in range(MIN_P, MAX_P + 1):
        if ready[pr]:
            return ready[pr].popleft()
    return None


def exists_higher_ready(ready, running):
    for pr in range(MIN_P, running.priority):
        if ready[pr]:
            return True
    return False


def print_deadlock_recovery_style(deadlocked_pids, victim_pid, released_dict):
    print("Processes that cause the deadlock are")
    for pid in deadlocked_pids:
        print(f"P{pid}")

    print(f"Recover from the deadlock by terminating P{victim_pid} and release all its resources")

    for rid in sorted(released_dict.keys()):
        k = released_dict[rid]
        if k > 0:
            print(f"Resource {rid} is preempted")

    print("*" * 60)


def run_preemptive_priority_rr_with_io(processes, resources, quantum=10, detect_deadlock=True):
    resource_ids = sorted(resources.keys())
    available = dict(resources)

    allocation = {p.PID: {rid: 0 for rid in resource_ids} for p in processes}
    request = {p.PID: {rid: 0 for rid in resource_ids} for p in processes}
    res_wait = []

    deadlock_events = []

    def can_grant(pid):
        return all(request[pid][rid] <= available.get(rid, 0) for rid in resource_ids)

    def grant_all(pid):
        for rid in resource_ids:
            k = request[pid][rid]
            if k > 0:
                available[rid] -= k
                allocation[pid][rid] += k
                request[pid][rid] = 0

    def try_wake_resource_waiters(current_time):
        nonlocal res_wait
        if not res_wait:
            return
        still = []
        for p in sorted(res_wait, key=lambda x: x.PID):
            if getattr(p, "killed", False):
                continue
            if can_grant(p.PID):
                grant_all(p.PID)
                add_to_ready(ready, p, current_time, front=False)
            else:
                still.append(p)
        res_wait = still

    ready = [deque() for _ in range(MAX_P + 1)]
    io_list = []
    arrivals = sorted(processes, key=lambda p: (p.ArrivalTime, p.PID))

    time = 0
    done = 0
    n = len(processes)
    running = None
    gantt = []

    pid_to_proc = {p.PID: p for p in processes}

    for p in processes:
        p.quantum_left = 0
        p.waiting_time = 0
        p.ready_wait = 0
        p.ready_enter_time = -1
        p.burst_i = 0
        p.event_i = 0
        p.remaining_T = 0
        p.io_remaining = 0
        p.state = "NEW"
        p.finish_time = None
        p.killed = False
        p.kill_time = None
        p.kill_reason = None

    def push_arrivals(current_time):
        nonlocal arrivals
        while arrivals and arrivals[0].ArrivalTime == current_time:
            p = arrivals.pop(0)
            if not p.killed:
                add_to_ready(ready, p, current_time, front=False)

    def start_running(p):
        p.state = "RUNNING"
        p.quantum_left = quantum
        return p

    def move_to_io(p, dur):
        p.state = "WAITING_IO"
        p.io_remaining = dur
        io_list.append(p)

    def count_ready_waiting_and_aging(current_time):
        temp = []
        for pr in range(MIN_P, MAX_P + 1):
            while ready[pr]:
                p = ready[pr].popleft()
                if getattr(p, "killed", False):
                    continue
                if getattr(p, "ready_enter_time", current_time) < current_time:
                    p.waiting_time += 1
                    p.ready_wait += 1
                    if p.ready_wait >= 10:
                        if p.priority > MIN_P:
                            p.priority -= 1
                        p.ready_wait = 0
                temp.append(p)
        for p in temp:
            ready[p.priority].append(p)

    def handle_cpu_events_until_T_or_block(p, current_time):
        cpu_events = p.burst_time[p.burst_i]["CPU"]
        while True:
            if p.event_i >= len(cpu_events):
                return "CPU_END"
            ev = cpu_events[p.event_i]

            if ev[0] == "T":
                if p.remaining_T == 0:
                    p.remaining_T = ev[1]
                return "T"

            if ev[0] == "R":
                _, rid, k = ev
                if rid not in available:
                    p.event_i += 1
                    continue
                request[p.PID][rid] += k
                if can_grant(p.PID):
                    grant_all(p.PID)
                    p.event_i += 1
                    continue

                p.state = "WAITING_RES"
                res_wait.append(p)

                #  MOD: do NOT declare deadlock here (avoids false positives)
                return "RES_BLOCK"

            if ev[0] == "F":
                _, rid, k = ev
                if rid not in available:
                    p.event_i += 1
                    continue
                freed = min(k, allocation[p.PID][rid])
                allocation[p.PID][rid] -= freed
                available[rid] += freed
                p.event_i += 1
                try_wake_resource_waiters(current_time)
                continue

            p.event_i += 1

    def remove_pid_from_ready(pid):
        for pr in range(MIN_P, MAX_P + 1):
            if ready[pr]:
                ready[pr] = deque([x for x in ready[pr] if x.PID != pid])

    def terminate_and_release(victim, current_time, reason):
        nonlocal running, io_list, res_wait, done
        victim.killed = True
        victim.kill_time = current_time
        victim.kill_reason = reason
        victim.state = "TERMINATED_BY_RECOVERY"

        released = {rid: 0 for rid in resource_ids}
        for rid in resource_ids:
            alloc_k = allocation[victim.PID][rid]
            if alloc_k > 0:
                available[rid] += alloc_k
                released[rid] = alloc_k
            allocation[victim.PID][rid] = 0
            request[victim.PID][rid] = 0

        remove_pid_from_ready(victim.PID)
        io_list = [p for p in io_list if p.PID != victim.PID]
        res_wait = [p for p in res_wait if p.PID != victim.PID]
        if running is not None and running.PID == victim.PID:
            running = None

        try_wake_resource_waiters(current_time)
        done += 1
        return released

    def recover_deadlock_by_termination(current_time):
        dead = detect_deadlock_snapshot(resource_ids, available, allocation, request, trace=False)
        if (not dead) or (len(dead) < 2):
            return None, dead if dead else []

        candidates = [pid_to_proc[pid] for pid in dead if not pid_to_proc[pid].killed]
        if not candidates:
            return None, dead

        victim = sorted(candidates, key=lambda x: (x.priority, x.PID), reverse=True)[0]
        released = terminate_and_release(victim, current_time, "Deadlock recovery")

        print_deadlock_recovery_style(dead, victim.PID, released)

        dead_after = detect_deadlock_snapshot(resource_ids, available, allocation, request, trace=False)
        deadlock_events.append({
            "time": current_time,
            "deadlocked_before": dead,
            "victim_pid": victim.PID,
            "victim_priority": victim.priority,
            "released": released,
            "deadlocked_after": dead_after
        })
        return victim.PID, dead_after

    # ---------------- MAIN LOOP ----------------
    while done < n:
        push_arrivals(time)

        # update IO
        new_io = []
        for p in io_list:
            if p.killed:
                continue
            p.io_remaining -= 1
            if p.io_remaining == 0:
                p.burst_i += 1
                add_to_ready(ready, p, time, front=False)
            else:
                new_io.append(p)
        io_list = new_io

        try_wake_resource_waiters(time)
        count_ready_waiting_and_aging(time)

        # preemption
        if running and exists_higher_ready(ready, running):
            add_to_ready(ready, running, time, front=False)
            running = None

        if running is None:
            cand = pick_best_ready(ready)
            if cand:
                running = start_running(cand)

        # MOD: if system fully stuck, check deadlock ONCE here
        if running is None:
            any_ready = any(len(q) > 0 for q in ready)
            if (not any_ready) and (len(io_list) == 0) and (len(res_wait) > 0):
                victim_pid = None
                if detect_deadlock and resource_ids:
                    victim_pid, _ = recover_deadlock_by_termination(time)

                # if not deadlock, then it's just a permanent block (not a cycle)
                # we stop to avoid infinite loop (and we do NOT kill)
                if victim_pid is None:
                    break

                # after recovery, retry same time tick
                continue

        if running is None:
            gantt.append((time, "IDLE"))
            time += 1
            continue

        if running.killed:
            running = None
            continue

        status = handle_cpu_events_until_T_or_block(running, time)

        if status == "RES_BLOCK":
            running = None
            continue

        if status == "CPU_END":
            running.burst_i += 1
            running.event_i = 0
            running.remaining_T = 0

            # normal termination releases ALL held resources
            if running.burst_i >= len(running.burst_time):
                running.finish_time = time
                running.state = "TERMINATED"

                for rid in resource_ids:
                    held = allocation[running.PID][rid]
                    if held > 0:
                        available[rid] += held
                        allocation[running.PID][rid] = 0
                    request[running.PID][rid] = 0

                try_wake_resource_waiters(time)

                done += 1
                running = None
                continue

            nb = running.burst_time[running.burst_i]
            if "IO" in nb:
                move_to_io(running, nb["IO"])
                running = None
            else:
                add_to_ready(ready, running, time, front=False)
                running = None
            continue

        # status is "T"
        gantt.append((time, f"P{running.PID}"))
        running.remaining_T -= 1
        running.quantum_left -= 1
        time += 1

        if running.remaining_T == 0:
            running.event_i += 1

        if running.quantum_left == 0:
            add_to_ready(ready, running, time, front=False)
            running = None

    return gantt, processes, deadlock_events


def print_gantt(gantt):
    if not gantt:
        print("empty gantt")
        return
    segments = []
    start, name = gantt[0]
    for t, n in gantt[1:]:
        if n != name:
            segments.append((start, t, name))
            start, name = t, n
    segments.append((start, gantt[-1][0] + 1, name))
    for s, e, n in segments:
        print(f"{s} to {e} process {n}")